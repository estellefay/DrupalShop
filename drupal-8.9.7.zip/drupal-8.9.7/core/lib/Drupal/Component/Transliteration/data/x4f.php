<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'zhong', 'qi', 'pei', 'yu', 'diao', 'dun', 'wu', 'yi', 'xin', 'kang', 'yi', 'ji', 'ai', 'wu', 'ji', 'fu',
  0x10 => 'fa', 'xiu', 'jin', 'pi', 'dan', 'fu', 'tang', 'zhong', 'you', 'huo', 'hui', 'yu', 'cui', 'chuan', 'san', 'wei',
  0x20 => 'chuan', 'che', 'ya', 'xian', 'shang', 'chang', 'lun', 'cang', 'xun', 'xin', 'wei', 'zhu', 'ze', 'xian', 'nu', 'bo',
  0x30 => 'gu', 'ni', 'ni', 'xie', 'ban', 'xu', 'ling', 'zhou', 'shen', 'qu', 'ci', 'beng', 'shi', 'jia', 'pi', 'yi',
  0x40 => 'si', 'yi', 'zheng', 'dian', 'han', 'mai', 'dan', 'zhu', 'bu', 'qu', 'bi', 'zhao', 'ci', 'wei', 'di', 'zhu',
  0x50 => 'zuo', 'you', 'yang', 'ti', 'zhan', 'he', 'bi', 'tuo', 'she', 'yu', 'yi', 'fu', 'zuo', 'gou', 'ning', 'tong',
  0x60 => 'ni', 'xian', 'qu', 'yong', 'wa', 'qian', 'shi', 'ka', 'bao', 'pei', 'hui', 'he', 'lao', 'xiang', 'ge', 'yang',
  0x70 => 'bai', 'fa', 'ming', 'jia', 'er', 'bing', 'ji', 'hen', 'huo', 'gui', 'quan', 'tiao', 'jiao', 'ci', 'yi', 'shi',
  0x80 => 'xing', 'shen', 'tuo', 'kan', 'zhi', 'gai', 'lai', 'yi', 'chi', 'kua', 'guang', 'li', 'yin', 'shi', 'mi', 'zhu',
  0x90 => 'xu', 'you', 'an', 'lu', 'mou', 'er', 'lun', 'dong', 'cha', 'chi', 'xun', 'gong', 'zhou', 'yi', 'ru', 'cun',
  0xA0 => 'xia', 'si', 'zai', 'lu', 'ta', 'jiao', 'zhen', 'ce', 'qiao', 'kuai', 'chai', 'ning', 'nong', 'jin', 'wu', 'hou',
  0xB0 => 'jiong', 'cheng', 'zhen', 'zuo', 'chou', 'qin', 'lu', 'ju', 'shu', 'ting', 'shen', 'tui', 'bo', 'nan', 'xiao', 'bian',
  0xC0 => 'tui', 'yu', 'xi', 'cu', 'e', 'qiu', 'xu', 'guang', 'ku', 'wu', 'jun', 'yi', 'fu', 'liang', 'zu', 'qiao',
  0xD0 => 'li', 'yong', 'hun', 'jing', 'qian', 'san', 'pei', 'su', 'fu', 'xi', 'li', 'fu', 'ping', 'bao', 'yu', 'qi',
  0xE0 => 'xia', 'xin', 'xiu', 'yu', 'di', 'che', 'chou', 'zhi', 'yan', 'lia', 'li', 'lai', 'si', 'jian', 'xiu', 'fu',
  0xF0 => 'huo', 'ju', 'xiao', 'pai', 'jian', 'biao', 'chu', 'fei', 'feng', 'ya', 'an', 'bei', 'yu', 'xin', 'bi', 'hu',
];

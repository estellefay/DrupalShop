<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'di', 'zhuang', 'le', 'lang', 'chen', 'cong', 'li', 'xiu', 'qing', 'shuang', 'fan', 'tong', 'guan', 'ze', 'su', 'lei',
  0x10 => 'lu', 'liang', 'mi', 'lou', 'chao', 'su', 'ke', 'chu', 'tang', 'biao', 'lu', 'jiu', 'zhe', 'zha', 'shu', 'zhang',
  0x20 => 'man', 'mo', 'niao', 'yang', 'tiao', 'peng', 'zhu', 'sha', 'xi', 'quan', 'heng', 'jian', 'cong', 'ji', 'yan', 'qiang',
  0x30 => 'xue', 'ying', 'er', 'xun', 'zhi', 'qiao', 'zui', 'cong', 'pu', 'shu', 'hua', 'kui', 'zhen', 'zun', 'yue', 'shan',
  0x40 => 'xi', 'chun', 'dian', 'fa', 'gan', 'mo', 'wu', 'qiao', 'rao', 'lin', 'liu', 'qiao', 'xian', 'run', 'fan', 'zhan',
  0x50 => 'tuo', 'lao', 'yun', 'shun', 'dun', 'cheng', 'tang', 'meng', 'ju', 'cheng', 'su', 'jue', 'jue', 'dian', 'hui', 'ji',
  0x60 => 'nuo', 'xiang', 'tuo', 'ning', 'rui', 'zhu', 'tong', 'zeng', 'fen', 'qiong', 'ran', 'heng', 'qian', 'gu', 'liu', 'lao',
  0x70 => 'gao', 'chu', 'xi', 'sheng', 'zi', 'san', 'ji', 'dou', 'jing', 'lu', 'jian', 'chu', 'yuan', 'ta', 'shu', 'jiang',
  0x80 => 'tan', 'lin', 'nong', 'yin', 'xi', 'sui', 'shan', 'zui', 'xuan', 'cheng', 'gan', 'ju', 'zui', 'yi', 'qin', 'pu',
  0x90 => 'yan', 'lei', 'feng', 'hui', 'dang', 'ji', 'sui', 'bo', 'ping', 'cheng', 'chu', 'zhua', 'gui', 'ji', 'jie', 'jia',
  0xA0 => 'qing', 'zhai', 'jian', 'qiang', 'dao', 'yi', 'biao', 'song', 'she', 'lin', 'li', 'cha', 'meng', 'yin', 'tao', 'tai',
  0xB0 => 'mian', 'qi', 'tuan', 'bin', 'huo', 'ji', 'qian', 'ni', 'ning', 'yi', 'gao', 'kan', 'yin', 'nou', 'qing', 'yan',
  0xC0 => 'qi', 'mi', 'zhao', 'gui', 'chun', 'ji', 'kui', 'po', 'deng', 'chu', 'ge', 'mian', 'you', 'zhi', 'huang', 'qian',
  0xD0 => 'lei', 'lei', 'sa', 'lu', 'li', 'cuan', 'lu', 'mie', 'hui', 'ou', 'lu', 'zhi', 'gao', 'du', 'yuan', 'li',
  0xE0 => 'fei', 'zhuo', 'sou', 'lian', 'jiang', 'chu', 'qing', 'zhu', 'lu', 'yan', 'li', 'zhu', 'chen', 'jie', 'e', 'su',
  0xF0 => 'huai', 'nie', 'yu', 'long', 'lai', 'jiao', 'xian', 'gui', 'ju', 'xiao', 'ling', 'ying', 'jian', 'yin', 'you', 'ying',
];

Existing Values Autocomplete Widget

<?php

namespace Drupal\search_api_autocomplete;

/**
 * Represents an exception that occurred in the Search API Autocomplete module.
 */
class SearchApiAutocompleteException extends \Exception {}
